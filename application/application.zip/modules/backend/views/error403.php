<div class="row">
  <div class="col-md-10 grid-margin mx-auto">
    <div class="card">
      <div class="card-body text-center">

          <h5 class="text-center">Error 403 ! anda tidak memiliki hak akses untuk layanan ini</h5>
          <a href="<?=site_url("backend/dashboard")?>" class="btn btn-primary btn-sm"><i class="fa fa-home"></i> Dashboard</a>
      </div>
    </div>
  </div>

</div>
